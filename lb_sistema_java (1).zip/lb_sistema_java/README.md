# LB Treinamento Personalizado — Sistema em Java

Sistema de cadastro de clientes para a academia/personal trainer "LB
Treinamento Personalizado", migrado do protótipo original em C para
Java (JavaFX + PostgreSQL), seguindo a documentação acadêmica validada
do projeto (histórias de usuário, requisitos funcionais/não funcionais,
modelagem de banco e plano de testes).

## Pré-requisitos

- JDK 17 ou superior
- Apache Maven 3.8+
- PostgreSQL 13+ (rodando localmente, ou ajuste `ConexaoBanco.java`)

## Configurando o banco de dados

1. Crie o banco:
   ```sql
   CREATE DATABASE lb_treinamento;
   ```
2. Rode o script `schema.sql` (cria as tabelas `usuarios` e `clientes`):
   ```bash
   psql -U postgres -d lb_treinamento -f schema.sql
   ```
3. Se o usuário/senha do PostgreSQL na sua máquina for diferente de
   `postgres`/`postgres`, ajuste as constantes `USUARIO` e `SENHA` em
   `src/main/java/com/lbtreinamento/database/ConexaoBanco.java`.

Na primeira execução, o sistema cria automaticamente um usuário
administrador padrão (`LBpersonal` / `LBP1234`) se ele ainda não
existir.

## Rodando o sistema

```bash
mvn clean javafx:run
```

> Se o seu computador estiver em uma rede de escola/laboratório e o
> Maven não conseguir baixar as dependências (erro de timeout para
> `repo.maven.apache.org`), é provável que seja um firewall da rede, e
> não um problema no código — teste em outra rede (ex.: um hotspot do
> celular) para confirmar, ou peça ao suporte de TI um proxy Maven.

## Rodando os testes (JUnit 5)

```bash
mvn test
```

Os testes de `ClienteRepositoryTest` exercitam o CRUD de clientes
(cadastrar, listar, excluir e a validação de e-mail duplicado — inclusive
com letras em caixas diferentes) e precisam de uma conexão válida com o
banco configurado acima, pois gravam e removem registros de teste reais.

## Gerando o executável (.exe)

```bash
mvn clean package
jpackage --type exe --name LBTreinamento --input target ^
  --main-jar lb-sistema-1.0.0.jar --main-class com.lbtreinamento.Main ^
  --win-console
```

(No Windows use `^` para quebrar linha; no Linux/Mac use `\`.)

## Estrutura do projeto

```
lb_sistema_java/
├── pom.xml
├── schema.sql
├── README.md
└── src/
    ├── main/java/com/lbtreinamento/
    │   ├── App.java                     (entrada JavaFX, usada por "mvn javafx:run")
    │   ├── Main.java                    (entrada do .jar/.exe empacotado)
    │   ├── model/
    │   │   ├── Usuario.java
    │   │   └── Cliente.java
    │   ├── database/
    │   │   ├── ConexaoBanco.java        (Singleton de conexão)
    │   │   ├── UsuarioRepository.java
    │   │   └── ClienteRepository.java   (todo o SQL de clientes + normalização de e-mail)
    │   └── ui/
    │       ├── LoginView.java
    │       ├── MainView.java
    │       └── CadastroClienteDialog.java
    └── test/java/com/lbtreinamento/database/
        └── ClienteRepositoryTest.java
```

## O que mudou nesta versão

1. **Telefone somente números**: o campo de telefone agora bloqueia
   qualquer caractere que não seja dígito já na digitação (antes
   aceitava espaços, parênteses e hífen para formatação). Continua
   exigindo exatamente 11 dígitos (DDD + número).
2. **E-mail sem diferenciação de maiúsculas/minúsculas**: o
   `ClienteRepository` agora normaliza todo e-mail para minúsculas antes
   de gravar (`cadastrar` e `atualizar`). Como essa classe é o único
   lugar do sistema que executa SQL sobre a tabela `clientes`, isso
   garante que "Ana@Email.com" e "ana@email.com" sejam sempre tratados
   como o mesmo e-mail — inclusive para a verificação de duplicidade.
   Efeito visível: depois de salvar, a lista de clientes mostra o
   e-mail já em minúsculas, podendo diferir da caixa digitada.
3. **Testes do Maven (JUnit)**: o `pom.xml` agora inclui a dependência
   `org.junit.jupiter:junit-jupiter` (escopo `test`) e o
   `maven-surefire-plugin`, exigidos pela documentação. Também foi
   criada a classe `ClienteRepositoryTest`, transcrita do plano de
   testes do próprio documento validado, para que `mvn test` realmente
   tenha testes para executar.

## Observação sobre verificação de sintaxe

Este ambiente de desenvolvimento não tem acesso a um compilador Java
nem à internet para baixar as dependências do Maven, então o código
não pôde ser compilado/testado de verdade aqui. Foi feita apenas uma
verificação automática de balanceamento de chaves/parênteses em cada
arquivo `.java` como sanidade mínima. Recomendo rodar `mvn clean
javafx:run` e `mvn test` na sua máquina para a validação real.
