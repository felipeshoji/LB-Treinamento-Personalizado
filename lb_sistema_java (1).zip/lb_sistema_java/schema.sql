-- Esquema do banco "lb_treinamento" — LB Treinamento Personalizado.
-- Corresponde ao Quadro 1 (Projeto de Banco de Dados) da documentação
-- validada do projeto.

CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario   SERIAL PRIMARY KEY,
    usuario      VARCHAR(30) NOT NULL UNIQUE,
    senha_hash   VARCHAR(64) NOT NULL,
    email        VARCHAR(50) NOT NULL UNIQUE,
    criado_em    TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS clientes (
    matricula        SERIAL PRIMARY KEY,
    nome_cliente     VARCHAR(50) NOT NULL,
    data_nascimento  DATE NOT NULL,
    telefone         VARCHAR(13) NOT NULL,
    email            VARCHAR(50) NOT NULL,
    anamnese         TEXT NOT NULL,
    criado_em        TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_clientes_telefone UNIQUE (telefone),
    CONSTRAINT uq_clientes_email    UNIQUE (email)
);

CREATE INDEX IF NOT EXISTS idx_clientes_nome ON clientes (nome_cliente);

-- Observações sobre as correções mais recentes do código:
--
-- 1) Telefone agora é gravado SOMENTE com dígitos (11 caracteres: DDD + número,
--    ex: "61999999999"). A coluna continua VARCHAR(13) — não é preciso
--    diminuir, pois 11 dígitos cabem tranquilamente, e manter 13 evita
--    precisar alterar o esquema caso algum dado antigo ainda tenha formatação
--    (espaços, parênteses ou hífen). Se quiser normalizar dados antigos para
--    conter somente dígitos, rode:
--      UPDATE clientes SET telefone = regexp_replace(telefone, '\D', '', 'g');
--
-- 2) E-mail agora é sempre normalizado para minúsculas pelo ClienteRepository
--    antes de cada INSERT/UPDATE (não há índice funcional/expression aqui —
--    a normalização acontece no código Java, já que ClienteRepository é o
--    único lugar do sistema que grava na tabela "clientes"). Se já existirem
--    e-mails cadastrados com letras maiúsculas, rode uma vez para igualar o
--    que já está no banco (evita duplicados "escondidos" por causa da caixa):
--      UPDATE clientes SET email = LOWER(email);
