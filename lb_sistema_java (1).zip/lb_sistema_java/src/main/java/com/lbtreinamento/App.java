package com.lbtreinamento;

import com.lbtreinamento.database.UsuarioRepository;
import com.lbtreinamento.ui.LoginView;
import com.lbtreinamento.ui.MainView;
import javafx.application.Application;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.sql.SQLException;

/**
 * Ponto de entrada da aplicação JavaFX. Garante que o usuário administrador
 * padrão exista no banco e, em seguida, mostra a tela de login.
 */
public class App extends Application {

    @Override
    public void start(Stage janelaPrincipal) {
        try {
            new UsuarioRepository().garantirAdminPadrao();
        } catch (SQLException erro) {
            new Alert(Alert.AlertType.ERROR,
                    "Não foi possível conectar ao banco de dados: " + erro.getMessage()).showAndWait();
            return;
        }

        mostrarTelaLogin(janelaPrincipal);
        janelaPrincipal.setTitle("LB Treinamento Personalizado");
        janelaPrincipal.show();
    }

    private void mostrarTelaLogin(Stage janelaPrincipal) {
        LoginView telaLogin = new LoginView(usuarioAutenticado -> {
            MainView telaPrincipal = new MainView(usuarioAutenticado,
                    () -> mostrarTelaLogin(janelaPrincipal));
            janelaPrincipal.setScene(telaPrincipal.getCena());
        });
        janelaPrincipal.setScene(telaLogin.getCena());
    }

    public static void main(String[] args) {
        launch(args);
    }
}
