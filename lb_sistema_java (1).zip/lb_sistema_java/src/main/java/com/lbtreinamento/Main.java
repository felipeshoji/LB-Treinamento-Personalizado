package com.lbtreinamento;

/**
 * Lançador "puro" (não estende Application) usado como classe principal do
 * jar sombreado (maven-shade-plugin). Isso evita o erro clássico
 * "JavaFX runtime components are missing" que ocorre quando um jar
 * executável tenta rodar uma classe Application diretamente sem que o
 * módulo javafx esteja no module-path.
 */
public class Main {
    public static void main(String[] args) {
        App.main(args);
    }
}
