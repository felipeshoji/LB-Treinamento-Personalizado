package com.lbtreinamento.database;

import com.lbtreinamento.model.Cliente;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Repositório (DAO) do Cliente. Concentra todo o SQL da tabela "clientes".
 * Implementa o CRUD completo: Cadastrar (Create), Listar (Read),
 * Atualizar (Update) e Excluir (Delete).
 *
 * Todas as colunas são NOT NULL no banco; telefone e email também são
 * UNIQUE (veja schema.sql) — nome, data de nascimento e anamnese não são
 * únicos, pois podem coincidir entre clientes diferentes.
 *
 * NORMALIZAÇÃO DO E-MAIL: antes de gravar, o e-mail é sempre convertido
 * para minúsculas (normalizarEmail()). Como esta classe é o ÚNICO lugar
 * do sistema que grava na tabela "clientes" (RNF06 — nenhuma tela executa
 * SQL diretamente), isso garante que, na prática, a comparação de e-mail
 * nunca diferencia maiúsculas de minúsculas: "Ana@Email.com" e
 * "ana@email.com" caem sempre no mesmo valor gravado, então a restrição
 * UNIQUE da coluna já barra os dois como duplicados.
 */
public class ClienteRepository {

    private static final String SQLSTATE_VIOLACAO_UNIQUE = "23505";

    public int cadastrar(Cliente cliente) throws SQLException {
        Connection conexao = ConexaoBanco.getInstancia().getConexao();

        String sql = "INSERT INTO clientes (nome_cliente, data_nascimento, telefone, email, anamnese) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, cliente.getNomeCliente());
            stmt.setDate(2, cliente.getDataNascimento() != null
                    ? Date.valueOf(cliente.getDataNascimento()) : null);
            stmt.setString(3, cliente.getTelefone());
            stmt.setString(4, normalizarEmail(cliente.getEmail()));
            stmt.setString(5, cliente.getAnamnese());

            stmt.executeUpdate();

            try (ResultSet chavesGeradas = stmt.getGeneratedKeys()) {
                if (chavesGeradas.next()) {
                    return chavesGeradas.getInt(1);
                }
                throw new SQLException("Não foi possível obter a matrícula gerada.");
            }
        } catch (SQLException erro) {
            throw traduzirErro(erro);
        }
    }

    public List<Cliente> listar() throws SQLException {
        Connection conexao = ConexaoBanco.getInstancia().getConexao();

        String sql = "SELECT matricula, nome_cliente, data_nascimento, telefone, email, anamnese "
                + "FROM clientes ORDER BY matricula";

        List<Cliente> clientes = new ArrayList<>();

        try (PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet resultado = stmt.executeQuery()) {

            while (resultado.next()) {
                Date dataSql = resultado.getDate("data_nascimento");

                Cliente cliente = new Cliente(
                        resultado.getInt("matricula"),
                        resultado.getString("nome_cliente"),
                        dataSql != null ? dataSql.toLocalDate() : null,
                        resultado.getString("telefone"),
                        resultado.getString("email"),
                        resultado.getString("anamnese")
                );
                clientes.add(cliente);
            }
        }

        return clientes;
    }

    public boolean atualizar(Cliente cliente) throws SQLException {
        Connection conexao = ConexaoBanco.getInstancia().getConexao();

        String sql = "UPDATE clientes SET nome_cliente = ?, data_nascimento = ?, "
                + "telefone = ?, email = ?, anamnese = ? WHERE matricula = ?";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, cliente.getNomeCliente());
            stmt.setDate(2, cliente.getDataNascimento() != null
                    ? Date.valueOf(cliente.getDataNascimento()) : null);
            stmt.setString(3, cliente.getTelefone());
            stmt.setString(4, normalizarEmail(cliente.getEmail()));
            stmt.setString(5, cliente.getAnamnese());
            stmt.setInt(6, cliente.getMatricula());

            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
        } catch (SQLException erro) {
            throw traduzirErro(erro);
        }
    }

    public boolean excluir(int matricula) throws SQLException {
        Connection conexao = ConexaoBanco.getInstancia().getConexao();

        String sql = "DELETE FROM clientes WHERE matricula = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, matricula);
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
        }
    }

    /**
     * Converte o e-mail para minúsculas antes de gravar (e tira espaços
     * nas pontas, por segurança). É essa normalização que faz o sistema
     * não diferenciar maiúsculas de minúsculas: como todo e-mail gravado
     * passa por aqui, dois e-mails "iguais a menos da caixa" viram
     * sempre o mesmo valor no banco.
     */
    private String normalizarEmail(String email) {
        return email == null ? null : email.trim().toLowerCase();
    }

    /**
     * Se o erro veio de uma violação de UNIQUE (SQLSTATE 23505), devolve
     * uma NOVA SQLException com mensagem amigável, identificando qual
     * campo está duplicado a partir do nome da constraint. Qualquer outro
     * tipo de erro de banco é devolvido como veio, sem alterar.
     */
    private SQLException traduzirErro(SQLException erro) {
        if (!SQLSTATE_VIOLACAO_UNIQUE.equals(erro.getSQLState())) {
            return erro;
        }

        String mensagemOriginal = erro.getMessage() != null ? erro.getMessage() : "";
        String mensagemAmigavel;

        if (mensagemOriginal.contains("uq_clientes_telefone")) {
            mensagemAmigavel = "Já existe um cliente cadastrado com esse telefone.";
        } else if (mensagemOriginal.contains("uq_clientes_email")) {
            mensagemAmigavel = "Já existe um cliente cadastrado com esse e-mail.";
        } else {
            mensagemAmigavel = "Já existe um cliente com um dado duplicado.";
        }

        return new SQLException(mensagemAmigavel, erro.getSQLState(), erro);
    }
}
