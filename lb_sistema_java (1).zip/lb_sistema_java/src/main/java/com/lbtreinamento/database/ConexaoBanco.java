package com.lbtreinamento.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoBanco {

    private static final String URL = "jdbc:postgresql://localhost:5432/lb_treinamento";
    private static final String USUARIO = "postgres";
    private static final String SENHA = "postgres";

    private static ConexaoBanco instancia;

    private Connection conexao;

    private ConexaoBanco() throws SQLException {
        this.conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
    }

    public static ConexaoBanco getInstancia() throws SQLException {
        if (instancia == null || instancia.conexao.isClosed()) {
            instancia = new ConexaoBanco();
        }
        return instancia;
    }

    public Connection getConexao() {
        return conexao;
    }

    public void fechar() throws SQLException {
        if (conexao != null && !conexao.isClosed()) {
            conexao.close();
        }
        instancia = null;
    }
}
