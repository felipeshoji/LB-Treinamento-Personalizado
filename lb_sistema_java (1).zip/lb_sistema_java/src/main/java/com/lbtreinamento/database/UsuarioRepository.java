package com.lbtreinamento.database;

import com.lbtreinamento.model.Usuario;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.Optional;

public class UsuarioRepository {

    private String gerarHash(String senha) {
        try {
            MessageDigest digestor = MessageDigest.getInstance("SHA-256");
            byte[] bytesHash = digestor.digest(senha.getBytes());

            StringBuilder construtor = new StringBuilder();
            for (byte b : bytesHash) {
                construtor.append(String.format("%02x", b));
            }
            return construtor.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Algoritmo de hash indisponível", e);
        }
    }

    public void garantirAdminPadrao() throws SQLException {
        Connection conexao = ConexaoBanco.getInstancia().getConexao();

        String sqlVerifica = "SELECT 1 FROM usuarios WHERE usuario = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sqlVerifica)) {
            stmt.setString(1, "LBpersonal");
            try (ResultSet resultado = stmt.executeQuery()) {
                if (resultado.next()) {
                    return;
                }
            }
        }

        String sqlInsere = "INSERT INTO usuarios (usuario, senha_hash, email) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sqlInsere)) {
            stmt.setString(1, "LBpersonal");
            stmt.setString(2, gerarHash("LBP1234"));
            stmt.setString(3, "lbpersonal@email.com");
            stmt.executeUpdate();
        }
    }

    public Optional<Usuario> autenticar(String usuario, String senha) throws SQLException {
        Connection conexao = ConexaoBanco.getInstancia().getConexao();

        String sql = "SELECT id_usuario, usuario, senha_hash, email FROM usuarios "
                + "WHERE usuario = ? AND senha_hash = ?";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, usuario);
            stmt.setString(2, gerarHash(senha));

            try (ResultSet resultado = stmt.executeQuery()) {
                if (resultado.next()) {
                    Usuario encontrado = new Usuario(
                            resultado.getInt("id_usuario"),
                            resultado.getString("usuario"),
                            resultado.getString("senha_hash"),
                            resultado.getString("email")
                    );
                    return Optional.of(encontrado);
                }
                return Optional.empty();
            }
        }
    }

    public Optional<Usuario> buscarPorEmail(String email) throws SQLException {
        Connection conexao = ConexaoBanco.getInstancia().getConexao();

        String sql = "SELECT id_usuario, usuario, senha_hash, email FROM usuarios WHERE email = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, email);

            try (ResultSet resultado = stmt.executeQuery()) {
                if (resultado.next()) {
                    Usuario encontrado = new Usuario(
                            resultado.getInt("id_usuario"),
                            resultado.getString("usuario"),
                            resultado.getString("senha_hash"),
                            resultado.getString("email")
                    );
                    return Optional.of(encontrado);
                }
                return Optional.empty();
            }
        }
    }
}
