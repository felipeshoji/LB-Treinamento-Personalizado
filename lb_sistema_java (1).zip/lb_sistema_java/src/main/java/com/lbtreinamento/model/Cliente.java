package com.lbtreinamento.model;

import java.time.LocalDate;

public class Cliente {

    private Integer matricula;
    private String nomeCliente;
    private LocalDate dataNascimento;
    private String telefone;
    private String email;
    private String anamnese;

    public Cliente() {
    }

    public Cliente(Integer matricula, String nomeCliente, LocalDate dataNascimento,
                   String telefone, String email, String anamnese) {
        this.matricula = matricula;
        this.nomeCliente = nomeCliente;
        this.dataNascimento = dataNascimento;
        this.telefone = telefone;
        this.email = email;
        this.anamnese = anamnese;
    }

    public Integer getMatricula() {
        return matricula;
    }

    public void setMatricula(Integer matricula) {
        this.matricula = matricula;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAnamnese() {
        return anamnese;
    }

    public void setAnamnese(String anamnese) {
        this.anamnese = anamnese;
    }

    @Override
    public String toString() {
        return "Cliente{matricula=" + matricula + ", nome='" + nomeCliente + "'}";
    }
}
