package com.lbtreinamento.model;

public class Usuario {

    private Integer idUsuario;
    private String usuario;
    private String senhaHash;
    private String email;

    public Usuario() {
    }

    public Usuario(Integer idUsuario, String usuario, String senhaHash, String email) {
        this.idUsuario = idUsuario;
        this.usuario = usuario;
        this.senhaHash = senhaHash;
        this.email = email;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenhaHash() {
        return senhaHash;
    }

    public void setSenhaHash(String senhaHash) {
        this.senhaHash = senhaHash;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Usuario{usuario='" + usuario + "', email='" + email + "'}";
    }
}
