package com.lbtreinamento.ui;

import com.lbtreinamento.model.Cliente;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.regex.Pattern;

/**
 * Janela (pop-up) usada tanto para CADASTRAR um cliente novo quanto para
 * EDITAR um cliente já existente.
 *
 * Layout em grade de 2 colunas (Nome+Email numa linha, Nascimento+Telefone
 * na linha seguinte, Anamnese ocupando a largura toda).
 */
public class CadastroClienteDialog extends Dialog<Cliente> {

    private static final String COR_DOURADO = "#a98c4b";
    private static final String COR_PRETO = "#111111";
    private static final String COR_BORDA_CAMPO = "#d9d7d0";
    private static final String COR_VINHO = "#7a1f1f";

    private static final Pattern PADRAO_EMAIL =
            Pattern.compile("^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$");

    // \p{L} = qualquer letra Unicode (inclui acentos: á, ã, ç, ...).
    // Também libera espaço, apóstrofo e hífen, para nomes como
    // "Maria D'Ávila" ou "João-Pedro" não ficarem travados.
    private static final Pattern PADRAO_CARACTERES_NOME =
            Pattern.compile("[\\p{L}\\s'-]*");

    // Telefone: SOMENTE dígitos (nada de espaço, parênteses ou hífen).
    private static final Pattern PADRAO_CARACTERES_TELEFONE =
            Pattern.compile("[0-9]*");
    private static final int QTD_DIGITOS_TELEFONE = 11; // DDD (2) + número (9)

    public CadastroClienteDialog() {
        this(null);
    }

    public CadastroClienteDialog(Cliente clienteParaEditar) {
        boolean modoEdicao = clienteParaEditar != null;

        setTitle(modoEdicao ? "Editar Cliente" : "Cadastrar Novo Cliente");
        setHeaderText(modoEdicao
                ? "Altere os dados do cliente e salve"
                : "Preencha as informações do novo cliente");

        getDialogPane().setStyle("-fx-background-color: white;");

        ButtonType botaoSalvar = new ButtonType(
                modoEdicao ? "Salvar Alterações" : "Salvar Cliente",
                ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(botaoSalvar, ButtonType.CANCEL);

        TextField campoNome = new TextField();
        campoNome.setPromptText("Digite o nome completo");
        campoNome.setStyle(estiloCampoTexto());
        campoNome.setTextFormatter(new TextFormatter<>(mudanca ->
                PADRAO_CARACTERES_NOME.matcher(mudanca.getControlNewText()).matches()
                        ? mudanca
                        : null
        ));

        DatePicker campoNascimento = new DatePicker();
        campoNascimento.setStyle(estiloCampoTexto());
        campoNascimento.setMaxWidth(Double.MAX_VALUE);
        // Desabilita visualmente as datas futuras no calendário. Sozinho não
        // é suficiente, porque o DatePicker também aceita digitar a data
        // direto no campo de texto — por isso o listener de valueProperty
        // logo abaixo também é necessário.
        campoNascimento.setDayCellFactory(seletor -> new DateCell() {
            @Override
            public void updateItem(LocalDate data, boolean vazia) {
                super.updateItem(data, vazia);
                if (data != null && data.isAfter(LocalDate.now())) {
                    setDisable(true);
                    setStyle("-fx-background-color: #f2f2f2; -fx-text-fill: #bbbbbb;");
                }
            }
        });

        TextField campoTelefone = new TextField();
        campoTelefone.setPromptText("61999999999 (somente números, 11 dígitos)");
        campoTelefone.setStyle(estiloCampoTexto());
        // Barra qualquer tecla que não seja dígito ANTES dela aparecer no campo.
        campoTelefone.setTextFormatter(new TextFormatter<>(mudanca ->
                PADRAO_CARACTERES_TELEFONE.matcher(mudanca.getControlNewText()).matches()
                        ? mudanca
                        : null
        ));

        TextField campoEmail = new TextField();
        campoEmail.setPromptText("email@exemplo.com");
        campoEmail.setStyle(estiloCampoTexto());

        TextArea campoAnamnese = new TextArea();
        campoAnamnese.setPromptText("Histórico médico, objetivos, limitações...");
        campoAnamnese.setPrefRowCount(4);
        campoAnamnese.setStyle(estiloCampoTexto());

        if (modoEdicao) {
            campoNome.setText(clienteParaEditar.getNomeCliente());
            campoNascimento.setValue(clienteParaEditar.getDataNascimento());
            campoTelefone.setText(clienteParaEditar.getTelefone());
            campoEmail.setText(clienteParaEditar.getEmail());
            campoAnamnese.setText(clienteParaEditar.getAnamnese());
        }

        Label labelErro = new Label();
        labelErro.setStyle("-fx-text-fill: " + COR_VINHO + "; -fx-font-size: 12px;");
        labelErro.setWrapText(true);

        // Validação IMEDIATA, sem esperar o clique em "Salvar":
        // telefone ao perder o foco, data de nascimento ao mudar o valor
        // (cobre tanto clique no calendário quanto digitação manual).
        campoTelefone.focusedProperty().addListener((observavel, estavaFocado, estaFocado) -> {
            if (Boolean.FALSE.equals(estaFocado) && !campoTelefone.getText().trim().isEmpty()) {
                String mensagem = validarTelefone(campoTelefone.getText());
                if (mensagem != null) {
                    labelErro.setText(mensagem);
                }
            }
        });

        campoNascimento.valueProperty().addListener((observavel, dataAntiga, dataNova) -> {
            if (dataNova != null && dataNova.isAfter(LocalDate.now())) {
                labelErro.setText("A data de nascimento não pode ser uma data futura!");
            }
        });

        // ---- Grade de 2 colunas, cada campo com seu rótulo em negrito por cima ----
        GridPane grade = new GridPane();
        grade.setHgap(20);
        grade.setVgap(16);
        grade.setPadding(new Insets(20));

        ColumnConstraints coluna = new ColumnConstraints();
        coluna.setPercentWidth(50);
        grade.getColumnConstraints().addAll(coluna, coluna);

        grade.add(campoComRotulo("Nome Completo:", campoNome), 0, 0);
        grade.add(campoComRotulo("Email:", campoEmail), 1, 0);
        grade.add(campoComRotulo("Data Nascimento:", campoNascimento), 0, 1);
        grade.add(campoComRotulo("Telefone:", campoTelefone), 1, 1);

        VBox blocoAnamnese = campoComRotulo("Anamnese:", campoAnamnese);
        grade.add(blocoAnamnese, 0, 2, 2, 1); // ocupa as 2 colunas

        grade.add(labelErro, 0, 3, 2, 1);

        getDialogPane().setContent(grade);
        getDialogPane().setPrefWidth(540);

        Button botaoSalvarNode = (Button) getDialogPane().lookupButton(botaoSalvar);
        botaoSalvarNode.setStyle("-fx-background-color: " + COR_DOURADO + "; -fx-text-fill: white; "
                + "-fx-font-weight: bold; -fx-background-radius: 6; -fx-padding: 8 18 8 18;");

        Button botaoCancelarNode = (Button) getDialogPane().lookupButton(ButtonType.CANCEL);
        botaoCancelarNode.setStyle("-fx-background-color: white; -fx-text-fill: " + COR_PRETO + "; "
                + "-fx-border-color: " + COR_BORDA_CAMPO + "; -fx-border-radius: 6; "
                + "-fx-background-radius: 6; -fx-padding: 8 18 8 18;");

        // Impede o Dialog de fechar quando a validação falha.
        botaoSalvarNode.addEventFilter(ActionEvent.ACTION, evento -> {
            String mensagemErro = validarCampos(
                    campoNome.getText(), campoNascimento.getValue(),
                    campoTelefone.getText(), campoEmail.getText(), campoAnamnese.getText());

            if (mensagemErro != null) {
                labelErro.setText(mensagemErro);
                evento.consume();
            }
        });

        setResultConverter(botaoClicado -> {
            if (botaoClicado != botaoSalvar) {
                return null;
            }

            Cliente cliente = modoEdicao ? clienteParaEditar : new Cliente();
            cliente.setNomeCliente(campoNome.getText().trim());
            cliente.setDataNascimento(campoNascimento.getValue());
            cliente.setTelefone(campoTelefone.getText().trim());
            // O ClienteRepository normaliza o e-mail para minúsculas antes de
            // gravar; aqui mantemos o que o usuário digitou (ele só vira
            // minúsculo quando a tela recarrega a lista a partir do banco).
            cliente.setEmail(campoEmail.getText().trim());
            cliente.setAnamnese(campoAnamnese.getText().trim());
            return cliente;
        });
    }

    /** Empilha um rótulo em negrito por cima do campo. */
    private VBox campoComRotulo(String texto, javafx.scene.control.Control campo) {
        Label rotulo = new Label(texto.replace(":", ""));
        rotulo.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-text-fill: " + COR_PRETO + ";");
        campo.setMaxWidth(Double.MAX_VALUE);
        VBox bloco = new VBox(4, rotulo, campo);
        return bloco;
    }

    private String estiloCampoTexto() {
        return "-fx-padding: 8; -fx-background-color: white; -fx-border-color: " + COR_BORDA_CAMPO + "; "
                + "-fx-border-radius: 6; -fx-background-radius: 6;";
    }

    /**
     * Valida todos os campos do formulário. Devolve a mensagem de erro do
     * PRIMEIRO problema encontrado, ou null se estiver tudo certo.
     */
    private String validarCampos(String nome, LocalDate nascimento,
                                  String telefone, String email, String anamnese) {

        if (nome == null || nome.trim().isEmpty()) {
            return "O nome do cliente é obrigatório!";
        }
        if (!PADRAO_CARACTERES_NOME.matcher(nome.trim()).matches()) {
            return "O nome não pode conter números!";
        }

        if (nascimento == null) {
            return "A data de nascimento é obrigatória!";
        }
        if (nascimento.isAfter(LocalDate.now())) {
            return "A data de nascimento não pode ser uma data futura!";
        }

        String mensagemTelefone = validarTelefone(telefone);
        if (mensagemTelefone != null) {
            return mensagemTelefone;
        }

        String emailDigitado = email == null ? "" : email.trim();
        if (emailDigitado.isEmpty()) {
            return "O e-mail é obrigatório!";
        }
        if (!PADRAO_EMAIL.matcher(emailDigitado).matches()) {
            return "Informe um e-mail em formato válido (ex: nome@dominio.com)!";
        }

        if (anamnese == null || anamnese.trim().isEmpty()) {
            return "A anamnese é obrigatória!";
        }

        return null;
    }

    /**
     * Valida só o campo telefone. Exige EXATAMENTE 11 dígitos (2 do DDD +
     * 9 do número) — ex: 61999999999. Como o campo já só aceita dígitos
     * na digitação, isto é uma segunda camada de segurança (por exemplo,
     * cobre o valor vindo pré-preenchido na edição).
     */
    private String validarTelefone(String telefone) {
        String telefoneLimpo = telefone == null ? "" : telefone.trim();
        if (telefoneLimpo.isEmpty()) {
            return "O telefone é obrigatório!";
        }

        String apenasDigitos = telefoneLimpo.replaceAll("\\D", "");
        if (apenasDigitos.length() != QTD_DIGITOS_TELEFONE) {
            return "O telefone deve ter exatamente " + QTD_DIGITOS_TELEFONE
                    + " dígitos (DDD + número, ex: 61999999999). Você digitou "
                    + apenasDigitos.length() + " dígito(s).";
        }

        return null;
    }
}
