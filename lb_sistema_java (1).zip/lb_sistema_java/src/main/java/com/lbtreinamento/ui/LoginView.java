package com.lbtreinamento.ui;

import com.lbtreinamento.database.UsuarioRepository;
import com.lbtreinamento.model.Usuario;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;

import java.sql.SQLException;
import java.util.Optional;
import java.util.function.Consumer;

public class LoginView {

    private static final String COR_FUNDO = "#efeeea";
    private static final String COR_DOURADO = "#a98c4b";
    private static final String COR_PRETO = "#111111";
    private static final String COR_CINZA_TEXTO = "#666666";
    private static final String COR_BORDA_CAMPO = "#d9d7d0";
    private static final String COR_VINHO = "#7a1f1f";

    private final UsuarioRepository repositorio = new UsuarioRepository();
    private final Scene cena;

    public LoginView(Consumer<Usuario> aoLogarComSucesso) {
        Label selo = new Label("STUDIO");
        selo.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: " + COR_DOURADO + ";");

        Label titulo = new Label("LB TREINAMENTO\nPERSONALIZADO");
        titulo.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: " + COR_PRETO + ";");
        titulo.setTextAlignment(TextAlignment.CENTER);
        titulo.setWrapText(true);

        Label subtitulo = new Label("SISTEMA DE GERENCIAMENTO INTERNO");
        subtitulo.setStyle("-fx-font-size: 11px; -fx-text-fill: " + COR_CINZA_TEXTO + ";");

        Label labelUsuario = new Label("USUÁRIO");
        labelUsuario.setStyle(estiloLabelCampo());

        TextField campoUsuario = new TextField();
        campoUsuario.setStyle(estiloCampoTexto());
        campoUsuario.setPrefWidth(300);

        Label labelSenha = new Label("SENHA");
        labelSenha.setStyle(estiloLabelCampo());

        PasswordField campoSenha = new PasswordField();
        campoSenha.setStyle(estiloCampoTexto());
        campoSenha.setPrefWidth(300);

        Label labelMensagem = new Label();
        labelMensagem.setStyle("-fx-text-fill: " + COR_VINHO + "; -fx-font-size: 12px;");
        labelMensagem.setWrapText(true);
        labelMensagem.setMaxWidth(300);

        Button botaoEntrar = new Button("ENTRAR");
        botaoEntrar.setMaxWidth(Double.MAX_VALUE);
        botaoEntrar.setStyle("-fx-background-color: " + COR_PRETO + "; -fx-text-fill: white; "
                + "-fx-font-weight: bold; -fx-padding: 12 0 12 0; -fx-background-radius: 6;");

        botaoEntrar.setOnAction(evento -> {
            String usuario = campoUsuario.getText().trim();
            String senha = campoSenha.getText().trim();

            if (usuario.isEmpty() || senha.isEmpty()) {
                labelMensagem.setText("Campos obrigatórios não preenchidos ou inválidos!");
                return;
            }
            if (senha.length() < 4 || senha.length() > 8) {
                labelMensagem.setText("Senha fora do padrão permitido!");
                return;
            }

            try {
                Optional<Usuario> autenticado = repositorio.autenticar(usuario, senha);
                if (autenticado.isPresent()) {
                    aoLogarComSucesso.accept(autenticado.get());
                } else {
                    labelMensagem.setText("Usuário ou senha incorretos!");
                }
            } catch (SQLException erro) {
                mostrarErroBanco(erro);
            }
        });

        campoSenha.setOnAction(evento -> botaoEntrar.fire());

        Hyperlink linkEsqueciSenha = new Hyperlink("Esqueceu a senha?");
        linkEsqueciSenha.setStyle("-fx-text-fill: " + COR_VINHO + "; -fx-font-size: 12px;");
        linkEsqueciSenha.setOnAction(evento -> recuperarSenha());

        VBox cartao = new VBox(10,
                selo, titulo, subtitulo,
                espaco(10),
                labelUsuario, campoUsuario,
                labelSenha, campoSenha,
                espaco(6),
                botaoEntrar, linkEsqueciSenha, labelMensagem);
        cartao.setAlignment(Pos.TOP_CENTER);
        cartao.setPadding(new Insets(32));
        cartao.setMaxWidth(360);
        cartao.setStyle("-fx-background-color: white; -fx-background-radius: 16; "
                + "-fx-border-color: " + COR_DOURADO + "; -fx-border-width: 1.5; -fx-border-radius: 16;");
        cartao.setEffect(new DropShadow(18, Color.rgb(0, 0, 0, 0.18)));

        StackPane raiz = new StackPane(cartao);
        raiz.setStyle("-fx-background-color: " + COR_FUNDO + ";");
        raiz.setPadding(new Insets(24));

        this.cena = new Scene(raiz, 460, 600);
    }

    private VBox espaco(double altura) {
        VBox espacador = new VBox();
        espacador.setPrefHeight(altura);
        return espacador;
    }

    private String estiloLabelCampo() {
        return "-fx-font-size: 11px; -fx-font-weight: bold; -fx-text-fill: " + COR_PRETO + ";";
    }

    private String estiloCampoTexto() {
        return "-fx-padding: 10; -fx-background-color: white; -fx-border-color: " + COR_BORDA_CAMPO + "; "
                + "-fx-border-radius: 6; -fx-background-radius: 6;";
    }

    private void recuperarSenha() {
        TextInputDialog dialogo = new TextInputDialog();
        dialogo.setTitle("Recuperar Senha");
        dialogo.setHeaderText(null);
        dialogo.setContentText("Digite seu e-mail cadastrado:");

        Optional<String> emailDigitado = dialogo.showAndWait();
        emailDigitado.ifPresent(email -> {
            try {
                Optional<Usuario> encontrado = repositorio.buscarPorEmail(email);
                Alert alerta;
                if (encontrado.isPresent()) {
                    alerta = new Alert(Alert.AlertType.INFORMATION,
                            "Link de redefinição de senha enviado para " + encontrado.get().getEmail());
                } else {
                    alerta = new Alert(Alert.AlertType.ERROR, "E-mail não encontrado no sistema.");
                }
                alerta.showAndWait();
            } catch (SQLException erro) {
                mostrarErroBanco(erro);
            }
        });
    }

    private void mostrarErroBanco(SQLException erro) {
        Alert alerta = new Alert(Alert.AlertType.ERROR, "Erro ao acessar o banco de dados: " + erro.getMessage());
        alerta.showAndWait();
    }

    public Scene getCena() {
        return cena;
    }
}
