package com.lbtreinamento.ui;

import com.lbtreinamento.database.ClienteRepository;
import com.lbtreinamento.model.Cliente;
import com.lbtreinamento.model.Usuario;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

public class MainView {

    private static final String COR_DOURADO = "#a98c4b";
    private static final String COR_PRETO = "#111111";
    private static final String COR_FUNDO = "#efeeea";
    private static final String COR_BORDA_CARTAO = "#e3e1da";
    private static final String COR_CINZA_TEXTO = "#666666";
    private static final String COR_VINHO = "#7a1f1f";

    private final ClienteRepository repositorio = new ClienteRepository();
    private final TableView<Cliente> tabela = new TableView<>();
    private final Scene cena;

    private final Button botaoEditar = new Button("Editar Cliente");
    private final Button botaoExcluir = new Button("Excluir Cliente");

    public MainView(Usuario usuarioLogado, Runnable aoSair) {
        BorderPane raiz = new BorderPane();
        raiz.setStyle("-fx-background-color: " + COR_FUNDO + ";");
        raiz.setTop(construirCabecalho(usuarioLogado, aoSair));
        raiz.setCenter(construirCartaoClientes());

        this.cena = new Scene(raiz, 900, 560);
        carregarClientes();
    }

    private HBox construirCabecalho(Usuario usuarioLogado, Runnable aoSair) {
        Label logo = new Label("LB");
        logo.setStyle("-fx-background-color: " + COR_DOURADO + "; -fx-text-fill: white; "
                + "-fx-font-weight: bold; -fx-padding: 8 12 8 12; -fx-background-radius: 6;");

        Label nomeSistema = new Label("LB TREINAMENTO PERSONALIZADO");
        nomeSistema.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 14px;");

        Label usuarioRotulo = new Label("  ·  " + usuarioLogado.getUsuario());
        usuarioRotulo.setStyle("-fx-text-fill: #bbbbbb; -fx-font-size: 12px;");

        HBox blocoEsquerda = new HBox(10, logo, nomeSistema, usuarioRotulo);
        blocoEsquerda.setAlignment(Pos.CENTER_LEFT);

        Button botaoSair = new Button("Sair");
        botaoSair.setStyle("-fx-background-color: transparent; -fx-text-fill: white; "
                + "-fx-border-color: #555555; -fx-border-radius: 6; -fx-background-radius: 6; "
                + "-fx-padding: 6 16 6 16;");
        botaoSair.setOnAction(evento -> aoSair.run());

        HBox cabecalho = new HBox(blocoEsquerda, criarEspacador(), botaoSair);
        cabecalho.setAlignment(Pos.CENTER_LEFT);
        cabecalho.setPadding(new Insets(14, 20, 14, 20));
        cabecalho.setStyle("-fx-background-color: " + COR_PRETO + ";");
        return cabecalho;
    }

    private VBox construirCartaoClientes() {
        Label titulo = new Label("Clientes");
        titulo.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + COR_PRETO + ";");

        Label subtitulo = new Label("Cadastre e gerencie os clientes da academia");
        subtitulo.setStyle("-fx-font-size: 12px; -fx-text-fill: " + COR_CINZA_TEXTO + ";");

        VBox blocoTitulo = new VBox(2, titulo, subtitulo);

        Button botaoCadastrar = new Button("Cadastrar Cliente");
        botaoCadastrar.setStyle(estiloBotaoPrimario());
        botaoCadastrar.setOnAction(evento -> abrirCadastro());

        botaoEditar.setStyle(estiloBotaoSecundario(COR_PRETO));
        botaoEditar.setOnAction(evento -> abrirEdicao());
        botaoEditar.setDisable(true);

        botaoExcluir.setStyle(estiloBotaoSecundario(COR_VINHO));
        botaoExcluir.setOnAction(evento -> excluirClienteSelecionado());
        botaoExcluir.setDisable(true);

        Button botaoAtualizar = new Button("Atualizar Lista");
        botaoAtualizar.setStyle(estiloBotaoSecundario(COR_PRETO));
        botaoAtualizar.setOnAction(evento -> carregarClientes());

        HBox linhaBotoes = new HBox(10, botaoCadastrar, botaoEditar, botaoExcluir, botaoAtualizar);
        linhaBotoes.setAlignment(Pos.CENTER_LEFT);

        HBox linhaTopo = new HBox(blocoTitulo, criarEspacador(), linhaBotoes);
        linhaTopo.setAlignment(Pos.CENTER_LEFT);

        tabela.getSelectionModel().selectedItemProperty().addListener((observavel, clienteAntigo, clienteNovo) -> {
            boolean temSelecao = clienteNovo != null;
            botaoEditar.setDisable(!temSelecao);
            botaoExcluir.setDisable(!temSelecao);
        });
        montarColunasTabela();
        VBox.setVgrow(tabela, Priority.ALWAYS);

        VBox cartao = new VBox(16, linhaTopo, tabela);
        cartao.setPadding(new Insets(24));
        cartao.setStyle("-fx-background-color: white; -fx-background-radius: 12; "
                + "-fx-border-color: " + COR_BORDA_CARTAO + "; -fx-border-radius: 12;");

        VBox envoltorio = new VBox(cartao);
        envoltorio.setPadding(new Insets(20));
        VBox.setVgrow(cartao, Priority.ALWAYS);
        return envoltorio;
    }

    private Region criarEspacador() {
        Region espacador = new Region();
        HBox.setHgrow(espacador, Priority.ALWAYS);
        return espacador;
    }

    private String estiloBotaoPrimario() {
        return "-fx-background-color: " + COR_DOURADO + "; -fx-text-fill: white; -fx-font-weight: bold; "
                + "-fx-background-radius: 6; -fx-padding: 8 16 8 16;";
    }

    private String estiloBotaoSecundario(String corTexto) {
        return "-fx-background-color: white; -fx-text-fill: " + corTexto + "; "
                + "-fx-border-color: #d9d7d0; -fx-border-radius: 6; -fx-background-radius: 6; "
                + "-fx-padding: 8 16 8 16;";
    }

    @SuppressWarnings("unchecked")
    private void montarColunasTabela() {
        TableColumn<Cliente, Number> colunaMatricula = new TableColumn<>("Matrícula");
        colunaMatricula.setCellValueFactory(new PropertyValueFactory<>("matricula"));

        TableColumn<Cliente, String> colunaNome = new TableColumn<>("Nome");
        colunaNome.setCellValueFactory(new PropertyValueFactory<>("nomeCliente"));
        colunaNome.setPrefWidth(180);

        TableColumn<Cliente, String> colunaNascimento = new TableColumn<>("Nascimento");
        colunaNascimento.setCellValueFactory(dadosCelula -> {
            var data = dadosCelula.getValue().getDataNascimento();
            String textoFormatado = data != null ? data.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) : "";
            return new javafx.beans.property.SimpleStringProperty(textoFormatado);
        });

        TableColumn<Cliente, String> colunaTelefone = new TableColumn<>("Telefone");
        colunaTelefone.setCellValueFactory(new PropertyValueFactory<>("telefone"));

        TableColumn<Cliente, String> colunaEmail = new TableColumn<>("Email");
        colunaEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colunaEmail.setPrefWidth(160);

        TableColumn<Cliente, String> colunaAnamnese = new TableColumn<>("Anamnese");
        colunaAnamnese.setCellValueFactory(new PropertyValueFactory<>("anamnese"));
        colunaAnamnese.setPrefWidth(220);

        tabela.getColumns().addAll(colunaMatricula, colunaNome, colunaNascimento,
                colunaTelefone, colunaEmail, colunaAnamnese);
        tabela.setPlaceholder(new Label("Nenhum cliente cadastrado"));
        tabela.setStyle("-fx-background-color: white;");
    }

    private void abrirCadastro() {
        CadastroClienteDialog dialogo = new CadastroClienteDialog();
        Optional<Cliente> resultado = dialogo.showAndWait();

        resultado.ifPresent(cliente -> {
            try {
                int matricula = repositorio.cadastrar(cliente);
                new Alert(Alert.AlertType.INFORMATION,
                        "Cliente cadastrado com sucesso! Matrícula: " + matricula).showAndWait();
                carregarClientes();
            } catch (SQLException erro) {
                new Alert(Alert.AlertType.ERROR,
                        "Erro ao cadastrar cliente: " + erro.getMessage()).showAndWait();
            }
        });
    }

    private void abrirEdicao() {
        Cliente clienteSelecionado = tabela.getSelectionModel().getSelectedItem();
        if (clienteSelecionado == null) {
            return;
        }

        CadastroClienteDialog dialogo = new CadastroClienteDialog(clienteSelecionado);
        Optional<Cliente> resultado = dialogo.showAndWait();

        resultado.ifPresent(clienteEditado -> {
            try {
                boolean atualizou = repositorio.atualizar(clienteEditado);
                if (atualizou) {
                    new Alert(Alert.AlertType.INFORMATION, "Cliente atualizado com sucesso!").showAndWait();
                } else {
                    new Alert(Alert.AlertType.WARNING,
                            "Não foi possível atualizar: o cliente pode ter sido excluído por outra pessoa.")
                            .showAndWait();
                }
                carregarClientes();
            } catch (SQLException erro) {
                new Alert(Alert.AlertType.ERROR,
                        "Erro ao atualizar cliente: " + erro.getMessage()).showAndWait();
            }
        });
    }

    private void excluirClienteSelecionado() {
        Cliente clienteSelecionado = tabela.getSelectionModel().getSelectedItem();
        if (clienteSelecionado == null) {
            return;
        }

        Alert confirmacao = new Alert(Alert.AlertType.CONFIRMATION,
                "Tem certeza que deseja excluir o cliente \"" + clienteSelecionado.getNomeCliente()
                        + "\" (matrícula " + clienteSelecionado.getMatricula() + ")? Essa ação não pode ser desfeita.",
                ButtonType.YES, ButtonType.NO);
        confirmacao.setTitle("Confirmar exclusão");
        confirmacao.setHeaderText(null);

        Optional<ButtonType> resposta = confirmacao.showAndWait();
        if (resposta.isPresent() && resposta.get() == ButtonType.YES) {
            try {
                boolean excluiu = repositorio.excluir(clienteSelecionado.getMatricula());
                if (excluiu) {
                    new Alert(Alert.AlertType.INFORMATION, "Cliente excluído com sucesso!").showAndWait();
                } else {
                    new Alert(Alert.AlertType.WARNING, "O cliente já não existia mais no banco.").showAndWait();
                }
                carregarClientes();
            } catch (SQLException erro) {
                new Alert(Alert.AlertType.ERROR,
                        "Erro ao excluir cliente: " + erro.getMessage()).showAndWait();
            }
        }
    }

    private void carregarClientes() {
        try {
            ObservableList<Cliente> clientes = FXCollections.observableArrayList(repositorio.listar());
            tabela.setItems(clientes);
        } catch (SQLException erro) {
            new Alert(Alert.AlertType.ERROR,
                    "Erro ao carregar clientes: " + erro.getMessage()).showAndWait();
        }

        botaoEditar.setDisable(true);
        botaoExcluir.setDisable(true);
    }

    public Scene getCena() {
        return cena;
    }
}
