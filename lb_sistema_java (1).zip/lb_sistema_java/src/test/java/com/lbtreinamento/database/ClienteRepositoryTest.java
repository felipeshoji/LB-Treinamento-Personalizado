package com.lbtreinamento.database;

import com.lbtreinamento.model.Cliente;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Testes do ClienteRepository, transcritos a partir do Quadro 2 (Plano de
 * Testes) da documentação validada do projeto. Requer uma conexão válida
 * com o banco "lb_treinamento" (ver ConexaoBanco) para ser executado.
 *
 * Executar com: mvn test
 */
class ClienteRepositoryTest {

    private final ClienteRepository repositorio = new ClienteRepository();
    private Integer matriculaCriada;

    private Cliente novoCliente(String telefone, String email) {
        return new Cliente(null, "Ana Souza", LocalDate.of(1990, 3, 15),
                telefone, email, "Sem restricoes");
    }

    @AfterEach
    void limpar() throws SQLException {
        if (matriculaCriada != null) {
            repositorio.excluir(matriculaCriada);
            matriculaCriada = null;
        }
    }

    @Test // CT08 - US04 CA2
    void deveCadastrarClienteValido() throws SQLException {
        matriculaCriada = repositorio.cadastrar(
                novoCliente("61900000001", "ana.teste@email.com"));

        assertTrue(matriculaCriada > 0);
        assertTrue(repositorio.listar().stream()
                .anyMatch(c -> c.getMatricula().equals(matriculaCriada)));
    }

    @Test // CT11 - US06 CA1
    void naoDeveCadastrarEmailDuplicado() throws SQLException {
        matriculaCriada = repositorio.cadastrar(
                novoCliente("61900000001", "ana.teste@email.com"));

        SQLException erro = assertThrows(SQLException.class, () ->
                repositorio.cadastrar(
                        novoCliente("61900000002", "ana.teste@email.com")));

        assertEquals("Já existe um cliente cadastrado com esse e-mail.",
                erro.getMessage());
    }

    @Test // Caso adicional - cobre a normalização de caixa do e-mail
    void naoDeveCadastrarEmailDuplicadoComCaixaDiferente() throws SQLException {
        matriculaCriada = repositorio.cadastrar(
                novoCliente("61900000004", "Ana.Teste@Email.com"));

        SQLException erro = assertThrows(SQLException.class, () ->
                repositorio.cadastrar(
                        novoCliente("61900000005", "ana.teste@email.com")));

        assertEquals("Já existe um cliente cadastrado com esse e-mail.",
                erro.getMessage());
    }

    @Test // CT17 - US09 CA2
    void deveExcluirCliente() throws SQLException {
        int matricula = repositorio.cadastrar(
                novoCliente("61900000003", "bia.teste@email.com"));

        assertTrue(repositorio.excluir(matricula));
        assertFalse(repositorio.excluir(matricula));
    }
}
